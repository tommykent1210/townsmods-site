<?php

/**
* 
*/
class Core
{
	
	public static function generateRandomString($length = 10) {
	    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	    $randomString = '';
	    for ($i = 0; $i < $length; $i++) {
	        $randomString .= $characters[mt_rand(0, strlen($characters) - 1)];
	    }
	    return $randomString;
	}

	public static function timestamp() {
		return time();
	}

	public static function trimDescription($description, $length) {
		return substr($description,0, $length - 3)."...";
	}

	public static function recalculateXP($id) {
		if (DB::table('users')->where('id', '=', $id)->count() == 1) {
			$userinfo = DB::table('users')->where('id', '=', $id)->first();
            $givenlikes = DB::table('likes')->where('uid', '=', $id)->count();
            $reclikes = 0;
            $userMods = DB::table('mods')->where('authorID', '=', $id)->get('id');

            foreach ($userMods as $mod) {
            	$count = DB::table('likes')->where('modid', '=', $mod->id)->count();
            	$reclikes += $count;
            }
            echo $givenlikes.'-'.$reclikes;

			//now we need to add together with any bonus XP
            $totalXP = intval(($givenlikes * intval(Config::get('townsmods.xpforlike'))) + ($reclikes * intval(Config::get('townsmods.xpforlikerec'))) + $userinfo->bonusxp);

            DB::table('users')->where('id', '=', $id)->update(array('xp' => $totalXP));
        }

	}
}

?>