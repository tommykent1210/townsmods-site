@layout('template')

@section('head')
@endsection

@section('title')
Message - Not found! 
@endsection

@section('content')
<div class="alert">
  <strong>Oops!</strong> We can't seem to find that message, perhaps it has been deleted!
</div>
@endsection
