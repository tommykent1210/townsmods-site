{{ Form::open('user/ucp/security') }}
	<fieldset>
		<legend>Security Settings</legend>
		<label>Current email (required):</label>
		<input type="text" id="current_email" required>
		<span class="help-inline">Please enter your current email address</span>
		<label>New email:</label>
		<input type="text" id="new_email">
		<span class="help-inline">Please enter a new email address if desired</span>
		<label>Confirm New email:</label>
		<input type="text" id="new_email_confirmation">
		<span class="help-inline">If you are changing your email address, please confirm it here</span>
		<legend></legend>
		<label>Current password (required):</label>
		<input type="password" id="current_password" required>
		<span class="help-inline">Please enter your current password for verification</span>
		<label>New Password:</label>
		<input type="password" id="new_password">
		<span class="help-inline">Please enter a new password</span>
		<label>Confirm New Password:</label>
		<input type="password" id="new_password_confirmation">
		<span class="help-inline">If you entered a new password, please confirm it here</span>
		<br />
		<button type="submit" class="btn">Submit</button>
	</fieldset>
{{ Form::close() }}