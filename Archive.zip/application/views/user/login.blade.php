@layout('template')

@section('head')
@endsection

@section('title')
Login
@endsection

@section('content')
<div class="span4 offset4 well well-small">
 <?php echo Form::open('user/login'); ?>
    <fieldset>
      <?php echo Form::label('email', 'Email Address:'); ?>
      <?php echo Form::text('email', '', array('class' =>'span4')); ?>
      <!-- password field -->
      <?php echo Form::label('password', 'Password:'); ?>
      <?php echo Form::password('password',array('class' =>'span4')); ?>

      <br />
      <?php echo Form::submit('Login', $attributes = array('class' => 'btn btn-success')); ?>
    </fieldset>
  <?php echo Form::close(); ?>
  <p>Don't have an account? <a href="{{URL::to('user/register')}}"> Register now!</a></p>
</div>
@endsection