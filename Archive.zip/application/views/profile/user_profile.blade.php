@layout('template')

@section('head')
@endsection

@section('title')
{{$userData->username}}'s Profile
@endsection

@section('content')
<div class="well">
	<legend>{{$userData->username}}'s Profile</legend>
	<table class="table table-bordered">
		<tr>
			<td width="40%"><strong>Username:</strong></td>
			<td>{{$userData->username}}</td>
		</tr>
		<tr>
			<td width="40%"><strong>Registration Date:</strong></td>
			<td>{{date('l jS \of F Y h:i:s A', $userData->registrationdate)}}</td>
		</tr>
		<tr>
			<td width="40%"><strong>Rank:</strong></td>
			<td>{{$userData->rank}}</td>
		</tr>
		<tr>
			<td width="40%"><strong>XP:</strong></td>
			<td>{{$userData->xp}}</td>
		</tr>

	</table>
</div>
@endsection