@layout('template')

@section('head')
@endsection

@section('title')
Login
@endsection

@section('content')
<div class="alert alert-error">
User not found. Please try another URL!
</div>
@endsection