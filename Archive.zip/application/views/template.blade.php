
<!DOCTYPE html>
<html lang="en">
  <head>
     {{ Asset::container('bootstrapper')->scripts() }}
    {{ HTML::script('js/jquery-ui-1.10.2.custom.min.js')}}
    {{ HTML::script('js/jasny-bootstrap.js')}}

    <meta charset="utf-8">
    @yield('head')
    <title>TownsMods.net -
    @yield('title')
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Le styles -->
    <style>
      body {
        padding-top: 0px; /* 60px to make the container go all the way to the bottom of the topbar */
      }
    </style>
    {{ Asset::container('bootstrapper')->styles() }}
    {{ HTML::style('css/jasny-bootstrap.css') }}
    {{ HTML::style('css/custom.css') }}
    {{ HTML::style('css/font-awesome.min.css') }}
    {{ HTML::style('css/prettify.css') }}

    <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <!-- Fav and touch icons -->
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="../assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="../assets/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="../assets/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="../assets/ico/apple-touch-icon-57-precomposed.png">
    <link rel="shortcut icon" href="../assets/ico/favicon.png">
    
  </head>

  <body style="padding-top: 0px;">
    <!-- nav -->
    @include('nav')

    
    @if ($bcArr != array())
    <div class="container">
    <ul class="breadcrumb">
        @foreach ($bcArr as $breadcrumb)
            @if(URL::to($breadcrumb[1]) == URL::current())
            <li><a href="{{URL::to($breadcrumb[1])}}">{{$breadcrumb[0]}}</a></li>
            @else
            <li><a href="{{URL::to($breadcrumb[1])}}">{{$breadcrumb[0]}}</a> <span class="divider">/</span></li>
            @endif
       
        @endforeach
    </ul>
    @endif
      @yield('content')
    </div> <!-- /container -->

    @include('footer')
    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    {{ HTML::script('js/highlighter/prettify.js') }}
    <script>prettyPrint();</script>
   

  </body>
</html>
