<html>
<head>
	<title>Verify your email address!</title>
</head>
<body>
Hi {{$name}},

<br />
Thanks for registering with TownsMods.net. To complete your registration and allow you to upload your own projects, please verify your email address by clicking the following link: <br />
<br />
<a href="{{$verify_link}}">{{$verify_link}}</a>

<br />
<br />
If you did not register, please simply ignore this email, your email and the associated account will be purged form our system after 7 days without verification.

</body>
</html>