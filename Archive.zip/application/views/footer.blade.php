<footer class="footer">
      <div class="container">
        <p>&copy; Copyright 2013 <a href="http://townsmods.net" target="_blank">Townsmods.net</a></p>
        <p>All mods and content are the property of their respective owners</p>
        <ul class="footer-links">
          <li><a href="{{ URL::to('about/dmca') }}"><i class="icon-warning-sign"> </i> Report Abuse</a></li>
          <li class="muted">·</li>
          <li><a href="{{URL::to('about/privacy')}}"><i class="icon-legal"> </i>Privacy Policy & Terms of Use</a></li>
        </ul>
      </div>
    </footer>

