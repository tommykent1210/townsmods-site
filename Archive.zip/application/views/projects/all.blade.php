@layout('template')

@section('head')
@endsection

@section('title')
{{$title}}
@endsection

@section('content')
	<div class="well well-small">

		<legend>{{$title}}
			<div class="pull-right">
				{{Form::open('projects/search', 'POST', array('class' => 'form-inline'))}}
				@if (Auth::check())
				  <a href="{{URL::to('projects/upload')}}" class="btn btn-success">New Project</a>
				@endif
				  {{ Form::text('search', '', array('class' => 'input-small', 'placeholder' => 'Search...')) }}
				  <button type="submit" class="btn">Search</button>
				{{Form::close()}}
			</div>
		</legend>
		@foreach ($projects->results as $project)
        <table>
        	<tr>
        		<td width="200px"><img alt="{{$project->title}}" src="{{URL::to('data/previewImage/'.$project->mainimage)}}" style="width:150px; height:150px;"></td>
        		<td><h3><a href="{{URL::to('projects/view/'.$project->modid)}}">{{$project->title}}</a> <small>- By: <a href="{{URL::to('profile/view/'.$project->id)}}">{{$project->username}}</a></small></h3>
	            <p>{{Core::trimDescription(BBCode::parse($project->description), 400)}}</p>
	            <p><a href="{{URL::to('projects/view/'.$project->id)}}" class="btn btn-primary">View Project</a></p></td>
        	</tr>
        </table>
        <legend></legend>
        @endforeach
        {{ $projects->links() }}

	</div>
@endsection