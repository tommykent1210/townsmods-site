@layout('template')

@section('head')
@endsection

@section('title')
Projects
@endsection

@section('content')
	<div class="well well-small">
            <legend>{{$project->title}} - v{{$project->version}} 
                <div class="pull-right">
                        @if (Auth::check()) 
                                @if($project->authorid != Auth::user()->id)
                                @if(DB::table('likes')->where('uid', '=', Auth::user()->id)->where('modid', '=', $project->id)->count() > 0)
                                <a href="{{URL::to('projects/unlike/'.$project->id)}}" class="btn btn-info"><i class="icon-star" style="color: #E0E01B"> </i> Liked</a>
                                @else
                                <a href="{{URL::to('projects/like/'.$project->id)}}" class="btn btn-info"><i class="icon-star"> </i> Like</a>
                                @endif
                                @endif
                        @endif
                </div>
            </legend>

                <div id="preview" class="carousel slide" style="min-height: 300px; background-color:#000000;">
                        
                        <!-- Carousel items -->
                        <div class="carousel-inner" id="carousel-inner" name="carousel-inner">
                        @for ($i = 0; $i < count($previewImages); $i++)
                                @if($i == 0)
                                <div class="item active">
                                @else
                                <div class="item">
                                @endif
                                        <img src="{{URL::to('data/previewimage/'.$previewImages[$i]->contentid)}}" alt="">
                                </div>
                        @endfor
                        </div>
                        <!-- Carousel nav -->
                        <a class="carousel-control left" href="#preview" data-slide="prev">&lsaquo;</a>
                        <a class="carousel-control right" href="#preview" data-slide="next">&rsaquo;</a>
                </div>
                @if ($project->supportedversion != Config::get('townsmods.currenttownsversion'))
                <div class="alert">
                  <button type="button" class="close" data-dismiss="alert">&times;</button>
                  <strong>Warning!</strong> We aren't sure if this mod will be fully compatible with the current version of Towns. Use this mod at your own risk.
                </div>

                @endif
                <div class="alert alert-info">
                        
                </div>
                <table class="table table-condensed">
                        <tr>
                                <td><h3>{{$project->title}} - v{{$project->version}}</h3></td>
                        </tr>
                        <tr>
                                <td>Uploaded by <a href="{{URL::to('profile/view/'.$user->id)}}">{{$user->username}}</a> at: {{$project->uploadeddate}}</td>
                        </tr>
                        <tr>
                                <td>
                                        <br />
                                        <p>{{BBCode::parse($project->description)}}</p>
                                </td>
                        </tr>
                </table>



	</div>
@endsection