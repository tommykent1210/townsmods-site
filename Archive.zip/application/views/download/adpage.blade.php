@layout('template')

@section('title')
Home
@endsection

@section('head')
<script type="text/javascript">

$(function(){
  var count = {{Config::get('townsmods.dlwaittime')}};
  countdown = setInterval(function(){
    $("#waitbutton").html("Please wait " +count + " seconds...");
    if (count < 0) {
        count = 0;
    }
    if (count == 0) {
        $("#waitbutton").html("Click here to download!");
        $("#waitbutton").removeClass('disabled');
    }
    count--;
  }, 1000);
});
</script>
@endsection

@section('content')
    <div class="well well-small">
        This is the ad page, needs work.
        <br />
        <a id="waitbutton" href="{{ URL::to('download/complete/'.$id.'/'.$hash) }}" class="btn btn-primary disabled">Please wait {{Config::get('townsmods.dlwaittime')}} seconds...</a>
	</div>
@endsection