<?php

return array(

	//email addresses
	'email_register' => 'accounts@townsmods.net',

	//current towns version
	'currenttownsversion' => '11',

	//download time
	'dlwaittime' => '10',

	//versions
	'versions' => array(
		'11a' => 'v11a',
		'11' => 'v11',
		'10a' => 'v10a',
		'10' => 'v10'
		
		),

	'xpforlike' => 1,

	'xpforlikerec' => 5,




);


?>