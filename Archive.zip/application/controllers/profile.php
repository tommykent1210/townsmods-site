<?php
// application/controllers/account.php
class Profile_Controller extends Base_Controller
{

    public $restful = true;

    public function get_index($username = "_null_")
    {

    	Log::write('info', ''.$username);
    	if ($username == "_null_") {
    		if (Auth::check() == false) {
    			Session::put('location', 'profile');
    			return Redirect::to('user/login');
			} else {
				$username = Auth::user()->username;
			}
        }
        //redirect to user control panel
    	return Redirect::to('user/cp');	
    	
    	
        
    }

    public function get_view($username = "_null_") {

        $breadcrumbs = array(
                array('Home', '/'),
                array('Profile', 'profile/view/'.$username),
                
                );

        Log::write('info', ''.$username);
         Session::put('location', 'profile'.$username);
        if ($username == "_null_") {
            if (Auth::check() == false) {
                Session::put('location', 'profile/');
                return Redirect::to('user/login');
            } else {
                $username = Auth::user()->username;
                Session::put('location', 'profile/view/'.$username);
            }  
        } 
        if (DB::table('users')->where('id', '=', $username)->count() == 1) {
            $user = DB::table('users')->where('id', '=', $username)->first();

            

            return View::make('profile.user_profile')->with('userData', $user)->with('bcArr', $breadcrumbs);
        } else {
            return View::make('profile.not_found')->with('bcArr', $breadcrumbs);
        }
        
        Session::put('location', 'profile/view/'.$username);

        
    }

}

?>