<?php
// application/controllers/account.php
class Data_Controller extends Base_Controller
{
    public function action_user() {
        $data = array();
        if (isset($_REQUEST['term'])) {
            $chars = $_REQUEST['term'];
            
            $usernames = DB::table('users')->where('username', 'LIKE', "%".$chars."%")->take(10)->get();
            
            foreach ($usernames as $username) {
                //echo $username['username'];
                $data[] = array(
                    'label' => $username->username,
                    'value' => $username->username
                );
            }
            
        } else {
            
            $data[0] = array(
                'label' => '',
                'value' => '');
        }
        echo json_encode($data);
        
    }

    public function action_previewImage($id = 0) {
        if ($id >0) {
            $pic = DB::table('content')->where('id', '=', $id)->where('active', '=', 1)->first();
            $loc = URL::base().'/cdn/';
            if ($pic != null) {
                
                $name = $loc.$pic->contenturl;
                $mime = File::mime($name);
                header("Content-Type: ".$mime);
                echo file_get_contents($name);
                exit;
                
            } else {
                return null;
            }
        }
    }
}

?>