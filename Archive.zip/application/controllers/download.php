<?php

class Download_Controller extends Base_Controller {

	public function action_index() {
		return Redirect::to('download/get/0');
	}

	public function action_get($id = 0)
	{
		$breadcrumbs = array(
            array('Home', '/'),
            array('Downloads', 'projects')
            );

		if ($id > 0) {
			if (DB::table('content')->where('id', '=', $id)->count() == 1) {
				$file = DB::table('content')->where('id', '=', $id)->first();
				$dlhash = Core::generateRandomString(32);
				Session::put('dlinit', time());
				Session::put('dlhash', $dlhash);

				return View::make('download.adpage')->with('bcArr', $breadcrumbs)->with('hash', $dlhash)->with('id', $id);
			} else {

			}
		} else {

		}
		
		
		
	}

	public function action_complete($id = 0, $hash = "null") {
		if ($id > 0 && $hash != "null") {
			if (Session::get('dlhash', 'null') == $hash) {
				Log::info(Session::get('dlinit') );
				Log::info(Config::get('townsmods.dlwaittime'));
				Log::info(time());
				if (Session::get('dlinit', 0) + Config::get('townsmods.dlwaittime') <= time() ) {
					$file = DB::table('content')->where('id','=',$id)->first();
					if($file) {
						$url = path('public').'/cdn/'.$file->contenturl;
						Log::info($url);
						if(file_exists($url)) {
							return Response::download($url, $file->title);
						} else {
							echo "missing0";//return Redirect::to('download/missing1');
						}
						
					} else {
						echo "missing1";//return Redirect::to('download/missing1');
					}
				} else {
					echo "missing2";//return Redirect::to('download/missing2');
				}
			} else {
				echo "missing3";//return Redirect::to('download/missing3');
			}
		} else {
			echo "missing4";//return Redirect::to('download/missing4');
		}
	}

	public function action_missing() {
		$breadcrumbs = array(
            array('Home', '/'),
            array('Missing Download', 'download/missing')
            );
		return View::make('download.missing')->with('bcArr', $breadcrumbs);
	}

}