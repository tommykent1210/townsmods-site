<?php
// application/controllers/account.php
class Projects_Controller extends Base_Controller
{

    public $restful = true;
    


    public function get_index()
    {
        return Redirect::to('projects/all');    
    }

    public function get_all() {
        //get all projects
        $breadcrumbs = array(
            array('Home', '/'),
            array('Projects', 'projects/all')
            );
        $projects = DB::table('mods')->join('users', 'users.id', '=', 'mods.authorid')->where('mods.active', '=', 1)->order_by('uploadedDate', 'desc')->paginate(10, array('users.id', 'users.username', 'mods.id as modid', 'mods.title', 'mods.description', 'mods.mainimage'));
        return View::make('projects.all')->with('bcArr', $breadcrumbs)->with('projects', $projects)->with('title', 'All Projects');
    }

    public function get_mods() {
        //get all projects
        $breadcrumbs = array(
            array('Home', '/'),
            array('Mods', 'projects/mods')
            );
        $projects = DB::table('mods')->join('users', 'users.id', '=', 'mods.authorid')->where('type', '=', 0)->where('mods.active', '=', 1)->order_by('uploadedDate', 'desc')->paginate(10, array('users.id', 'users.username', 'mods.id as modid', 'mods.title', 'mods.description', 'mods.mainimage'));
        return View::make('projects.all')->with('bcArr', $breadcrumbs)->with('projects', $projects)->with('title', 'All Mods');
    }

    public function get_saves() {
        //get all projects
        $breadcrumbs = array(
            array('Home', '/'),
            array('Saves', 'projects/saves')
            );
        $projects = DB::table('mods')->join('users', 'users.id', '=', 'mods.authorid')->where('type', '=', 1)->where('mods.active', '=', 1)->order_by('uploadedDate', 'desc')->paginate(10, array('users.id', 'users.username', 'mods.id as modid', 'mods.title', 'mods.description', 'mods.mainimage'));
        return View::make('projects.all')->with('bcArr', $breadcrumbs)->with('projects', $projects)->with('title', 'All Saves');
    }

    public function get_view($id = 1) {


        $project = DB::table('mods')->where('active', '=', 1)->where('id', '=', $id)->first();

        if ($project != null) {
            $breadcrumbs = array(
                array('Home', '/'),
                array('Projects', 'projects'),
                array(Core::trimDescription($project->title, 50), 'projects/view/'.$id),
                );
            $previewImages = DB::table('modContent')->join('content', 'modContent.contentID', '=', 'content.id')->where('modContent.modID', '=', $id)->where('content.type', '=', '2')->get();
            $user = DB::table('users')->where('id', '=', $project->authorid)->first();
            return View::make('projects.view')->with('bcArr', $breadcrumbs)->with('project', $project)->with('previewImages', $previewImages)->with('user', $user);
        }
    }


    public function get_like($id = 0) {
        if ($id > 0) {
            if (DB::table('likes')->where('uid', '=', Auth::user()->id)->where('modid', '=', $id)->count() == 0) {
                DB::table('likes')->insert(array(
                    'uid' => Auth::user()->id,
                    'modid' => $id));
                $modid = DB::table('mods')->where('id', '=', $id)->first();
                Core::recalculateXP($modid->authorid);
                Core::recalculateXP(Auth::user()->id);

            } 
        }

        //recalculate both Users XP

        return Redirect::to('projects/view/'.$id);
    }

    public function get_unlike($id = 0) {
        if ($id > 0) {
            if (DB::table('likes')->where('uid', '=', Auth::user()->id)->where('modid', '=', $id)->count() == 1) {
                DB::table('likes')->where('uid', '=', Auth::user()->id)->where('modid', '=', $id)->delete();
                $modid = DB::table('mods')->where('id', '=', $id)->first();
                Core::recalculateXP($modid->authorid);
                Core::recalculateXP(Auth::user()->id);
            } 
        }
        return Redirect::to('projects/view/'.$id);
    }

    public function get_upload() {
        $breadcrumbs = array(
            array('Home', '/'),
            array('Projects', 'projects/all'),
            array('Upload', 'projects/upload')
            );

        if (Auth::check() && Auth::user()->active == 1 && Auth::user()->usergroup == 2) {
            return View::make('projects.upload')->with('bcArr', $breadcrumbs);
        } else {
            return Redirect::to('/');
        }
    }

    public function post_upload() {
        $input = Input::all();
        //var_dump($input);
        //exit;

        $rules = array(
            'projecttitle' => 'required|min:5|max:255',
            'message' => 'required|min:10',
            'type' => 'required',
            'previewimage' => 'required|image',
            'maindownload' => 'required|mimes:zip|max:5000',
            'version' => 'required',
            'supportedversions' => 'required'
            );

        $v = Validator::make($input, $rules);
        //change the language, so it works with message = project description
        $v->speaks('tr');


        if ($v->fails()) {
            //oops, shit went down boi.
            return Redirect::to('projects/upload')->with_input()->with('has_errors', true)->with_errors($v);
        } else {
            //yay!

            //save the data, getting the ID
            $modID = DB::table('mods')->insert_get_id(array(
                'authorID' => Auth::user()->id,
                'active' => '1',
                'title' => $input['projecttitle'],
                'description' => $input['message'],
                'version' => $input['version'],
                'supportedVersion' => $input['supportedversions'],
                'mainimage' => '0',
                'type' => $input['type'],
                'downloads' => 0
                ));

            //now we have the ID, we can begin uploading the files, using the ID as a prefix
            //get the unique name for the preview image
            $name = $modID.'-'.Core::generateRandomString(16).".".File::extension(Input::file('previewimage.name'));
            Input::upload('previewimage', 'public/cdn/img/', $name);
            $mainImageID = DB::table('content')->insert_get_id(array(
                'contentURL' => 'img/'.$name,
                'active' => '1',
                'type' => 2,
                'title' => $name
                ));

            //after inputting, create a link between the project and the image
            DB::table('modContent')->insert(array(
                'modID' => $modID,
                'contentID' => $mainImageID,
                'active' => 1));

            //now, for the main file, do the same
            $name = $modID.'-'.Core::generateRandomString(16).".".File::extension(Input::file('maindownload.name'));
            Input::upload('maindownload', 'public/cdn/zip/', $name);
            $mainDLID = DB::table('content')->insert_get_id(array(
                'contentURL' => 'zip/'.$name,
                'active' => '1',
                'type' => 1,
                'title' => $name
                ));

            //after inputting, create a link between the project and the image
            DB::table('modContent')->insert(array(
                'modID' => $modID,
                'contentID' => $mainDLID,
                'active' => 1));

            //finally, update the original mod entry for the main preview image
            DB::table('mods')->where('id', '=', $modID)->update(array(
                'mainImage' => $mainImageID,
                'mainDownload' => $mainDLID));

            return Redirect::to('projects/view/'.$modID);


        }
    }

    public function get_search() {
        return Redirect::to('projects/all');
    }

    public function post_search() {
        $input = Input::get('search');

        //var_dump($input);
        //exit;
        if ($input) {
            $query = $input;
            $breadcrumbs = array(
                array('Home', '/'),
                array('Projects', 'projects/all'),
                array('Search: '.$query, 'projects/all')
                );
            $numprojects = DB::table('mods')->join('users', 'users.id', '=', 'mods.authorid')->where('mods.active', '=', 1)->where('title', 'LIKE', '%'.$query.'%')->or_where('description', 'LIKE','%'.$query.'%')->count();
            $projects = DB::table('mods')->join('users', 'users.id', '=', 'mods.authorid')->where('mods.active', '=', 1)->where('title', 'LIKE', '%'.$query.'%')->or_where('description', 'LIKE','%'.$query.'%')->order_by('uploadedDate', 'desc')->paginate(10, array('users.id', 'users.username', 'mods.id as modid', 'mods.title', 'mods.description', 'mods.mainimage'));
            if($numprojects == 0) {
                return Redirect::to('projects/all');
            }
            return View::make('projects.all')->with('bcArr', $breadcrumbs)->with('projects', $projects)->with('title', 'All Saves');
        
        } else {
            return Redirect::to('projects/all');
        }

    }
}

?>