<?php
include 'src'.DS.'start.php';
